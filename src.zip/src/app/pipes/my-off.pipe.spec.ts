import { MyOffPipe } from './my-off.pipe';

describe('MyOffPipe', () => {
  it('create an instance', () => {
    const pipe = new MyOffPipe();
    expect(pipe).toBeTruthy();
  });
});
