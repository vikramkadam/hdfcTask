import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ftwo',
  templateUrl: './ftwo.component.html',
  styleUrls: ['./ftwo.component.css']
})
export class FtwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
