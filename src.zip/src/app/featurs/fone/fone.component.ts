import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fone',
  templateUrl: './fone.component.html',
  styleUrls: ['./fone.component.css']
})
export class FoneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
